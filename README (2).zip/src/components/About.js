import React from "react";

function About() {
  return <h1> Hey, Im on the About Pge</h1>;
}
export default About;
