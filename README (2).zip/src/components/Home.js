function Home() {
  return <h2>Welcome to Our Home Page</h2>;
}
export default Home;
