import React from "react";

function Courses() {
  return <h1> Hey, Im on the Courses Pge</h1>;
}
export default Courses;
